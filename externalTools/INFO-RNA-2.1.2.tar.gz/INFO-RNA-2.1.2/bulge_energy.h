#ifndef _BULGE_ENERGY__
#define _BULGE_ENERGY__

#include <stdlib.h>
#include "basics.h"
#include "constraints.h"

using namespace std;

double BulgeEnergy(int size, int bp_i, int bp_j, int bp_before);

#endif   // _BULGE_ENERGY_
